<?php
// Text
$_['text_upload']    = 'Seu arquivo foi enviado.';

// Error
$_['error_filename'] = 'O nome do arquivo deve ter entre 3 e 64 caracteres.';
$_['error_filetype'] = 'O tipo de arquivo não é válido.';
$_['error_upload']   = 'O arquivo para upload é obrigatório.';