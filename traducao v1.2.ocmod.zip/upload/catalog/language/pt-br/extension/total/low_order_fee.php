<?php
$_['text_low_order_fee'] = 'Taxa para pedidos pequenos';