<?php
// Text
$_['text_title']       = 'Frete por quantidade';
$_['text_description'] = 'Frete por quantidade';