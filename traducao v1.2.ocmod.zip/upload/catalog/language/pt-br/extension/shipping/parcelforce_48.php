<?php
// Text
$_['text_title']       = 'Parcelforce 48';
$_['text_description'] = 'Parcelforce 48';
$_['text_weight']      = 'Peso:';
$_['text_insurance']   = 'Com seguro até:';
$_['text_time']        = 'Prazo de entrega: Estimado em 48 horas.';