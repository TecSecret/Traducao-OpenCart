<?php
// Text
$_['text_title']    = 'Australia Post';
$_['text_express']  = 'Expresso';
$_['text_standard'] = 'Avançado';
$_['text_eta']      = 'dias';