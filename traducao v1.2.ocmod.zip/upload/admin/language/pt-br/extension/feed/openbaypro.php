<?php
/**
 * Tradução Opencart mantida pela TecSecret
 * @author     Departamento de Desenvolvimento Web - TecSecret | Responsável: Nelsir Luterek
 * @copyright  Copyright (c) 2016 https://tecsecret.com.br
 */
// Heading
$_['heading_title']  = 'OpenBay Pro';

// Text
$_['text_module']    = 'Módulos';
$_['text_installed'] = 'A extensão OpenBay Pro já está instalada. Ela está disponível no menu Extensões -> OpenBay Pro';