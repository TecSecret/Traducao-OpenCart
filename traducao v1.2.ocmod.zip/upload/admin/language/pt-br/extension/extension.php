<?php
/**
 * Tradução Opencart mantida pela TecSecret
 * @author     Departamento de Desenvolvimento Web - TecSecret | Responsável: Nelsir Luterek
 * @copyright  Copyright (c) 2016 https://tecsecret.com.br
 */
// Heading
$_['heading_title']  = 'Extensões';

// Text
$_['text_success']   = 'Você modificou a extensão com sucesso!';
$_['text_list']      = 'Listando extensões';
$_['text_type']      = 'Selecione o tipo de extensão';
$_['text_filter']    = 'Filtrar';
$_['text_analytics'] = 'Estatística';
$_['text_captcha']   = 'Antispam';
$_['text_dashboard'] = 'Painel';
$_['text_feed']      = 'Alimentador';
$_['text_fraud']     = 'Antifraude';
$_['text_module']    = 'Módulo';
$_['text_content']   = 'Conteúdo de módulo';
$_['text_menu']      = 'Menu';
$_['text_payment']   = 'Pagamento';
$_['text_shipping']  = 'Frete';
$_['text_theme']     = 'Tema';
$_['text_total']     = 'Total do pedido';