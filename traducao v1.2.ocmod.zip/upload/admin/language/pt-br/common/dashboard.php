<?php
/**
 * Tradução Opencart mantida pela TecSecret
 * @author     Departamento de Desenvolvimento Web - TecSecret | Responsável: Nelsir Luterek
 * @copyright  Copyright (c) 2016 https://tecsecret.com.br
 */
// Heading
$_['heading_title'] = 'Painel de controle';

// Error
$_['error_install'] = 'Atenção: A pasta install não foi excluída! Para manter a segurança de sua loja, exclua a pasta install.';