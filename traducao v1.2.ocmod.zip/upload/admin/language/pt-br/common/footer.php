<?php
/**
 * Tradução Opencart mantida pela TecSecret
 * @author     Departamento de Desenvolvimento Web - TecSecret | Responsável: Nelsir Luterek
 * @copyright  Copyright (c) 2016 https://tecsecret.com.br
 */
// Text
$_['text_footer']  = '<a href="http://www.tecsecret.com.br" target="_blank"><img src="http://tecsecret.com.br/logos/tecsecret.png" alt="TecSecret - A Sua Consultoria em TI" title="TecSecret - A Sua Consultoria em TI"></a>
<br />OpenCart  v%s';
$_['text_version'] = 'Versão %s';