<?php
/**
 * Tradução Opencart mantida pela TecSecret
 * @author     Departamento de Desenvolvimento Web - TecSecret | Responsável: Nelsir Luterek
 * @copyright  Copyright (c) 2016 https://tecsecret.com.br
 */
$_['text_complete_status']   = 'Finalizados'; 
$_['text_processing_status'] = 'Processando'; 
$_['text_other_status']      = 'Outras situações'; 