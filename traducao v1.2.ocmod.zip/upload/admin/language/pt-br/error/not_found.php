<?php
/**
 * Tradução Opencart mantida pela TecSecret
 * @author     Departamento de Desenvolvimento Web - TecSecret | Responsável: Nelsir Luterek
 * @copyright  Copyright (c) 2016 https://tecsecret.com.br
 */
// Heading
$_['heading_title']  = 'Página não encontrada!';

// Text
$_['text_not_found'] = 'A página que você está procurando não pode ser encontrada! Entre em contato com o administrador da loja caso o problema persistir.';