<?php
/**
 * Tradução Opencart mantida pela TecSecret
 * @author     Departamento de Desenvolvimento Web - TecSecret | Responsável: Nelsir Luterek
 * @copyright  Copyright (c) 2016 https://tecsecret.com.br
 */
// Heading
$_['heading_title']   = 'Permissão negada!';

// Text
$_['text_permission'] = 'Você não tem permissão para acessar esta página, consulte o administrador do loja para mais informações.';