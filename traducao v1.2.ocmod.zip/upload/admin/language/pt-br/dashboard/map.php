<?php
/**
 * Tradução Opencart mantida pela TecSecret
 * @author     Departamento de Desenvolvimento Web - TecSecret | Responsável: Nelsir Luterek
 * @copyright  Copyright (c) 2016 https://tecsecret.com.br
 */
// Heading
$_['heading_title'] = 'Mapa geográfico de vendas';

$_['text_order']    = 'Pedidos';
$_['text_sale']     = 'Vendas';