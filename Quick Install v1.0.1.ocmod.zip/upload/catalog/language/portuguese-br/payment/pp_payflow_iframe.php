<?php
// Text
$_['text_title']				= 'Cart�o de cr�dito ou d�bito';
$_['text_secure_connection']	= 'Acessando conex�o segura...';

// Error
$_['error_connection']			= 'N�o foi poss�vel conectar ao PayPal. Entre em contato com nosso atendimento para lhe ajudarmos a concluir seu pagamento.';