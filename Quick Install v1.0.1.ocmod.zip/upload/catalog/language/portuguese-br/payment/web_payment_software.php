<?php
// Text
$_['text_title']				= 'Cart�o de cr�dito ou d�bito (Web Payment Software)';
$_['text_credit_card']			= 'Detalhes do cart�o';

// Entry
$_['entry_cc_owner']			= 'Titular do cart�o';
$_['entry_cc_number']			= 'N�mero do cart�o';
$_['entry_cc_expire_date']		= 'V�lido at�';
$_['entry_cc_cvv2']				= 'C�digo de seguran�a (CVV2)';