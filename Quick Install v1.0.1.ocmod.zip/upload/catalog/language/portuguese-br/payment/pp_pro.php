<?php
// Text
$_['text_title']				= 'Cart�o de cr�dito ou d�bito (pagamento seguro pelo PayPal)';
$_['text_wait']					= 'Aguarde...';
$_['text_credit_card']			= 'Detalhes do cart�o';
$_['text_loading']				= 'Carregando';

// Entry
$_['entry_cc_type']				= 'Tipo de cart�o';
$_['entry_cc_number']			= 'N�mero do cart�o';
$_['entry_cc_start_date']		= 'V�lido at�';
$_['entry_cc_expire_date']		= 'Expira em';
$_['entry_cc_cvv2']				= 'C�digo de seguran�a (CVV2)';
$_['entry_cc_issue']			= 'Pergunta de seguran�a';

// Help
$_['help_start_date']			= '(se dispon�vel)';
$_['help_issue']				= '(somente para Maestro e Solo)';