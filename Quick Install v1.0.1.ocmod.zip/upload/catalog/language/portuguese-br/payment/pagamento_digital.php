<?php
$_['text_title'] 			= 'Bcash';
$_['text_extra_amount']		= 'Frete e Taxas';
$_['button_confirm_bcash'] 	= 'Confirmar e pagar no Bcash';
?>