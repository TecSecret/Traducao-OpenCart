<?php
// Text
$_['text_title'] = 'Pagar quando retirar na loja';