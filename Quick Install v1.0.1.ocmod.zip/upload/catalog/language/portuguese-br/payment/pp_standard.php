<?php
// Text
$_['text_title']	= 'PayPal';
$_['text_testmode']	= 'Aten��o: O pagamento est� em modo de teste. Sua conta n�o ser� carregada.';
$_['text_total']	= 'Frete, descontos, impostos e taxas';