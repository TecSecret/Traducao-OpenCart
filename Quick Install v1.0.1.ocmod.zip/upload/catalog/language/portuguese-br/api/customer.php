<?php
// Text
$_['text_success']       = 'O cliente foi modificado com sucesso';

// Error
$_['error_permission']   = 'Aten��o: Voc� n�o tem permiss�o de acesso a API!';
$_['error_firstname']    = 'O nome deve ter entre 2 e 32 caracteres!';
$_['error_lastname']     = 'O sobrenome deve entre 2 e 32 caracteres!';
$_['error_email']        = 'O e-mail n�o � v�lido!';
$_['error_telephone']    = 'O telefone deve ter entre 10 e 32 caracteres!';
$_['error_custom_field'] = 'O campo %s � obrigat�rio!';