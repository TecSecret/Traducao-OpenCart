<?php
// Text
$_['text_title']       = 'Fixo';
$_['text_description'] = 'Frete fixo';