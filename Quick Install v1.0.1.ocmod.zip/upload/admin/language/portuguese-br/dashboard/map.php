<?php
// Heading
$_['heading_title'] = 'Mapa do mundo';

$_['text_order']    = 'Pedidos';
$_['text_sale']     = 'Vendas';