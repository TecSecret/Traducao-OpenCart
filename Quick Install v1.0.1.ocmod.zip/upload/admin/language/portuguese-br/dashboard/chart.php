<?php
// Heading
$_['heading_title'] = 'Gráfico de vendas';

// Text
$_['text_order']    = 'Pedidos';
$_['text_customer'] = 'Clientes';
$_['text_day']      = 'Hoje';
$_['text_week']     = 'Semanal';
$_['text_month']    = 'Mensal';
$_['text_year']     = 'Anual';