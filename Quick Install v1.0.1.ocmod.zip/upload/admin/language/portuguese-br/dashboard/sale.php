<?php
// Heading
$_['heading_title'] = 'Total de vendas';

// Text
$_['text_view']     = 'Ver mais...';