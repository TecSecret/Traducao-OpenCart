<?php
// Text
$_['text_footer'] 	= '<a href="http://www.tecsecret.com.br" target="_blank"><img src="http://tecsecret.com.br/logos/tecsecret.png" alt="Desenvolvido por TecSecret" title="Desenvolvido por TecSecret"></a>';
$_['text_version'] 	= 'TecLoja Standard v%s';