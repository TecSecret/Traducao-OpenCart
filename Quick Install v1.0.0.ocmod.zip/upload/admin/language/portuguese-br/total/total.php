<?php
// Heading
$_['heading_title']    = 'Total';

// Text
$_['text_total']       = 'Total de pedidos';
$_['text_success']	   = 'Total modificado com sucesso!';
$_['text_edit']        = 'Configurações do Total';

// Entry
$_['entry_status']     = 'Situação';
$_['entry_sort_order'] = 'Posição';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para modificar o Total!';