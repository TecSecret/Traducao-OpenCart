<?php
// Text
$_['text_title']		   = 'Cart�o de cr�dito ou d�bito (Authorize.Net)';
$_['text_credit_card']     = 'Detalhes do cart�o';

// Entry
$_['entry_cc_owner']       = 'T�tular do cart�o';
$_['entry_cc_number']      = 'N�mero do cart�o';
$_['entry_cc_expire_date'] = 'Expira em';
$_['entry_cc_cvv2']		   = 'C�digo de seguran�a (CVV2)';