<?php
// Text
$_['text_title']				= 'Cart�o de cr�dito ou d�bito (Paymate)';
$_['text_unable']				= 'N�o foi poss�vel localizar ou atualizar a situa��o do pedido';
$_['text_declined']				= 'O pagamento n�o foi aceito por Paymate';
$_['text_failed']				= 'A transa��o de pagamento falhou';
$_['text_failed_message']		= '<p>Infelizmente houve um erro ao processar sua transa��o.</p><p><b>Aten��o: </b>%s</p><p>Verifique o seu saldo na conta Paymate antes de tentar pagar novamente.</p><p> Se voc� acredita que esta transa��o foi conclu�da com �xito, ou est� aparecendo como dedu��o na sua conta Paymate, entre em <a href="%s">contato</a> e nos informe os detalhes.</p>';
$_['text_basket']				= 'Carrinho de compras';
$_['text_checkout']				= 'Finalizar pedido';
$_['text_success']				= 'Confirma��o';