<?php
// Text
$_['text_success']     = 'O cupom foi utilizado com sucesso';

// Error
$_['error_permission'] = 'Aten��o: Voc� n�o tem permiss�o de acesso a API!';
$_['error_coupon']     = 'Aten��o: O cupom � inv�lido, expirou, atingiu o seu limite de uso ou j� foi utilizado!';