<?php
// Text
$_['text_success']     = 'O carrinho de compras foi modificado com sucesso';

// Error
$_['error_permission'] = 'Aten��o: Voc� n�o tem permiss�o de acesso a API!';
$_['error_stock']      = 'Os produtos marcados com *** n�o est�o dispon�veis na quantia solicitada ou n�o encontram-se em estoque!';
$_['error_minimum']    = 'A quantidade m�nima para %s � %s!';
$_['error_store']      = 'O produto n�o pode ser comprado na loja selecionada!';
$_['error_required']   = 'O campo %s � obrigat�rio!';