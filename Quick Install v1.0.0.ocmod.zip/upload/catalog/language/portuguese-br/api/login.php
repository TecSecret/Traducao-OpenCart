<?php
// Text
$_['text_success'] = 'A API foi iniciada com sucesso';

// Error
$_['error_login']  = 'Aten��o: Os dados de acesso n�o s�o v�lidos.';