<?php
// Text
$_['text_success'] = 'A API foi iniciada com sucesso';

// Error
$_['error_key']    = 'Atenção: A chave de acesso a API não é válida!';
$_['error_ip']     = 'Atenção: O seu IP %s não tem permissão para acessar esta API!';
