<?php
// Text
$_['text_title']				= 'Cartão de crédito ou débito';
$_['text_secure_connection']	= 'Acessando a conexão segura...';

// Error
$_['error_connection']			= 'Não foi possível conectar ao PayPal. Entre em contato com nosso atendimento para lhe ajudarmos a concluir seu pagamento.';