<?php
// Text
$_['text_title'] = 'Cartão de crédito ou débito (NOCHEX)';