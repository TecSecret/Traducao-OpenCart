<?php
// Text
$_['text_title']		   = 'Cartão de crédito ou débito (Web Payment Software)';
$_['text_credit_card']	   = 'Detalhes do cartão';

// Entry
$_['entry_cc_owner']	   = 'Titular do cartão';
$_['entry_cc_number']	   = 'Número do cartão';
$_['entry_cc_expire_date'] = 'Expira em';
$_['entry_cc_cvv2']		   = 'Código de segurança (CVV2)';