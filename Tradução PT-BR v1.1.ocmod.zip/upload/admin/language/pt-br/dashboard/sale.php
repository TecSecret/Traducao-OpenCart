<?php
// Heading
$_['heading_title'] = 'Total vendido';

// Text
$_['text_view']     = 'Ver mais...';