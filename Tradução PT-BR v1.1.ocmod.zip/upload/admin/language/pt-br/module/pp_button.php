<?php
// Heading
$_['heading_title']    = 'Botão PayPal Express Checkout';

// Text
$_['text_module']      = 'Módulos';
$_['text_success']     = 'Botão PayPal Express Checkout modificado com sucesso!';
$_['text_edit']        = 'Editando Botão PayPal Express Checkout';

// Entry
$_['entry_status']     = 'Situação';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para modificar a extensão Botão PayPal Express Checkout!';