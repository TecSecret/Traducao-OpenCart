<?php
// Heading
$_['heading_title']    = 'Menu de departamentos';

// Text
$_['text_module']      = 'Módulos';
$_['text_success']     = 'Menu de departamentos modificado com sucesso!';
$_['text_edit']        = 'Editando Menu de departamentos';

// Entry
$_['entry_status']     = 'Situação';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para modificar a extensão Menu de departamentos!';