<?php
// Heading
$_['heading_title']    = 'Cupom';

// Text
$_['text_total']       = 'Total de pedidos';
$_['text_success']	   = 'Cupom modificado com sucesso!';
$_['text_edit']        = 'Editando Cupom';

// Entry
$_['entry_status']     = 'Situação';
$_['entry_sort_order'] = 'Posição';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para modificar a extensão Cupom!';