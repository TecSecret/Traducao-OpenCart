<?php
// Text
$_['text_title'] = 'Cartão de crédito ou débito / Paypal / Wallet (G2APay)';