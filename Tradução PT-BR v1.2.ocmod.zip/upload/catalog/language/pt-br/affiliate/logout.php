<?php
// Heading
$_['heading_title'] = 'Sair';

// Text
$_['text_message']  = '<p>Você saiu de sua conta. Esse é o método mais seguro para que ninguém acesse sua conta.</p>';
$_['text_account']  = 'Programa de afiliados';
$_['text_logout']   = 'Sair';