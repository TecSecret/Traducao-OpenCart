<?php
// Heading
$_['heading_title']    = 'Temas';

// Text
$_['text_success']     = 'Tema modificado com sucesso!';
$_['text_list']        = 'Listando temas';

// Column
$_['column_name']      = 'Tema';
$_['column_status']    = 'Situação';
$_['column_action']    = 'Ação';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para modificar os temas!';