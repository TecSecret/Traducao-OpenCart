<?php
// Heading
$_['heading_title']    = 'Menu do afiliado';

// Text
$_['text_extension']   = 'Extensões';
$_['text_success']     = 'Menu do afiliado modificado com sucesso!';
$_['text_edit']        = 'Editando Menu do afiliado';

// Entry
$_['entry_status']     = 'Situação';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para modificar a extensão Menu do afiliado!';