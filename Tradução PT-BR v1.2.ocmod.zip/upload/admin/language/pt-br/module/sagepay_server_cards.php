<?php
// Heading
$_['heading_title']    = 'Sagepay Server Card Management';

// Text
$_['text_module']      = 'Módulos';
$_['text_success']     = 'Sagepay Server Card Management modificado com sucesso!';
$_['text_edit']        = 'Editando Sagepay Server Card Management';

// Entry
$_['entry_status']     = 'Situação';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para modificar a extensão Sagepay Server Card Management!';